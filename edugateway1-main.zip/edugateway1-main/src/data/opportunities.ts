export interface Opportunity {
  id: string;
  title: string;
  type: "scholarship" | "program" | "other";
  typeLabel: string;
  country: string;
  countryFlag: string;
  description: string; // pipe-separated segments
  buttonText: string;
  url?: string;
  internalLink?: string;
}

// ============ HOME TOP PICKS ============
export const homeTopPicks: Opportunity[] = [
  {
    id: "home-uwc",
    title: "United World Colleges (UWC)",
    type: "scholarship",
    typeLabel: "Scholarship",
    country: "kosovo",
    countryFlag: "🇽🇰",
    description: "UWC is a global network of international boarding schools where students from more than 150 countries study together and complete the International Baccalaureate (IB) diploma.|Key details:|Age: 16–18|Duration: 2 years|Scholarship: many students receive full funding covering tuition and living costs|Kosovo students apply through the national UWC committee.",
    buttonText: "Visit Website",
    url: "https://apply.uwc.org/",
  },
  {
    id: "home-yes",
    title: "Youth Exchange and Study Program (YES)",
    type: "program",
    typeLabel: "Program",
    country: "usa",
    countryFlag: "🇺🇸",
    description: "The YES program is a fully funded exchange program supported by the U.S. Department of State that allows students from countries with significant Muslim populations, including Kosovo, to study in an American high school for one year.|Key details:|Age: usually 15–17 years old|Duration: 1 academic year|Coverage: flights, tuition, housing with host family, insurance, and stipend",
    buttonText: "Visit Website",
    url: "https://exchanges.state.gov/non-us/program/kennedy-lugar-youth-exchange-study-yes",
  },
  {
    id: "home-usa-guide",
    title: "USA College Scholarships & Guide",
    type: "other",
    typeLabel: "Guide",
    country: "usa",
    countryFlag: "🇺🇸",
    description: "A dedicated section for students who want to study in the United States.|Includes:|Full scholarships|Application guides|SAT/TOEFL info|Tips for Kosovo students",
    buttonText: "Open Section",
    internalLink: "/usa",
  },
];

// ============ SCHOLARSHIPS ============
export const scholarships: Opportunity[] = [
  {
    id: "s-uwc", title: "United World Colleges (UWC)", type: "scholarship", typeLabel: "Scholarship",
    country: "kosovo", countryFlag: "🇽🇰",
    description: "UWC is a global network of international boarding schools where students from more than 150 countries study together and complete the International Baccalaureate (IB) diploma.|Key details:|Age: 16–18|Duration: 2 years|Scholarship: many students receive full funding covering tuition and living costs|Kosovo students apply through the national UWC committee.",
    buttonText: "Visit Website", url: "https://apply.uwc.org/",
  },
  {
    id: "s-assist", title: "ASSIST Scholars Program", type: "scholarship", typeLabel: "Scholarship",
    country: "usa", countryFlag: "🇺🇸",
    description: "ASSIST places talented international students into top private high schools in the United States on merit-based scholarships.|Key details:|Age: usually 15–17|Duration: 1 academic year|Coverage: large tuition scholarships|Students from countries without offices can still apply directly.",
    buttonText: "Visit Website", url: "https://www.assistscholars.org/",
  },
  {
    id: "s-globalvision", title: "Global Vision Scholarship", type: "scholarship", typeLabel: "Scholarship",
    country: "usa", countryFlag: "🇺🇸",
    description: "The Global Vision Scholarship supports international students enrolling in an online American high school program.|Key details:|Age: 14+|Study type: online high school courses|Scholarship: covers up to six courses toward a U.S. diploma|Requires internet access and English proficiency.",
    buttonText: "Visit Website", url: "https://smartschools-international.org/program/",
  },
  {
    id: "s-raiseme", title: "RaiseMe Micro-Scholarships", type: "scholarship", typeLabel: "Scholarship",
    country: "usa", countryFlag: "🇺🇸",
    description: "RaiseMe is an online platform that allows high school students to earn micro-scholarships for achievements.|Key details:|Students build a scholarship portfolio during high school|Many universities participate|Awards are based on academic achievements.",
    buttonText: "Visit Website", url: "https://www.raise.me/",
  },
  {
    id: "s-schoolfund", title: "The School Fund Scholarships", type: "scholarship", typeLabel: "Scholarship",
    country: "international", countryFlag: "🌍",
    description: "This nonprofit helps students continue their education through crowdfunded scholarships.|Key details:|Open to students from many countries|Scholarships help cover school fees|Often targeted at students with financial need.",
    buttonText: "Visit Website", url: "https://theschoolfund.org/",
  },
  {
    id: "s-tortuga", title: "Tortuga Study Abroad Scholarship", type: "scholarship", typeLabel: "Scholarship",
    country: "international", countryFlag: "🌍",
    description: "A travel-focused scholarship for students interested in studying abroad.|Key details:|Award: around $1,000|Open to international students|Requires an essay about travel and education|Lower competition compared to major scholarships.",
    buttonText: "Visit Website", url: "https://www.tortugabackpacks.com/pages/study-abroad-scholarship",
  },
  {
    id: "s-daad", title: "DAAD High School Scholarships", type: "scholarship", typeLabel: "Scholarship",
    country: "germany", countryFlag: "🇩🇪",
    description: "Scholarships funded by Germany that support international students in academic exchange and study programs.|Key details:|Age: high school students|Location: Germany|Coverage: partial to full funding|Focus on academic excellence and cultural exchange.",
    buttonText: "Visit Website", url: "https://www.daad.de/en/",
  },
  {
    id: "s-sbw", title: "SBW Berlin Scholarship", type: "scholarship", typeLabel: "Scholarship",
    country: "germany", countryFlag: "🇩🇪",
    description: "A fully funded scholarship in Germany for young people committed to social projects.|Key details:|Coverage: tuition, housing, stipend|Level: high school graduates / university pathway|Focus: leadership and social impact|Open to students from developing countries including Kosovo.",
    buttonText: "Visit Website", url: "https://sbw.berlin/en/sbw-berlin-scholarship/",
  },
  {
    id: "s-hungary", title: "Hungarian Diaspora Scholarship", type: "scholarship", typeLabel: "Scholarship",
    country: "europe", countryFlag: "🇭🇺",
    description: "A scholarship program funded by Hungary that supports students from various countries.|Key details:|Coverage: tuition, accommodation, stipend|Level: mainly for future university studies|Good long-term opportunity for planning ahead.",
    buttonText: "Visit Website", url: "https://diasporascholarship.hu/en/",
  },
  {
    id: "s-erasmus", title: "Erasmus+ Scholarships", type: "scholarship", typeLabel: "Scholarship",
    country: "europe", countryFlag: "🇪🇺",
    description: "European Union funded opportunities supporting education, exchanges, and youth participation across Europe.|Key details:|Coverage: travel, accommodation, participation costs|Includes exchanges, training, and youth programs|Widely accessible to Balkan students.",
    buttonText: "Visit Website", url: "https://erasmus-plus.ec.europa.eu/",
  },
  {
    id: "s-turkiye", title: "Türkiye Scholarships", type: "scholarship", typeLabel: "Scholarship",
    country: "europe", countryFlag: "🇹🇷",
    description: "A fully funded scholarship program by the Turkish government for international students.|Key details:|Coverage: tuition, housing, stipend, flights|Level: mainly university preparation|Popular among Balkan students.",
    buttonText: "Visit Website", url: "https://www.turkiyeburslari.gov.tr/",
  },
  {
    id: "s-afs", title: "AFS Global Scholarships", type: "scholarship", typeLabel: "Scholarship",
    country: "international", countryFlag: "🌍",
    description: "AFS offers intercultural exchange scholarships for high school students worldwide.|Key details:|Age: 15–18|Duration: semester or year|Coverage: often partial or full funding|Focus: cultural exchange and global learning.",
    buttonText: "Visit Website", url: "https://www.afs.org/",
  },
  {
    id: "s-austria", title: "Austrian Government Scholarships", type: "scholarship", typeLabel: "Scholarship",
    country: "europe", countryFlag: "🇦🇹",
    description: "Scholarships provided by Austria for international students through various exchange programs.|Key details:|Coverage: tuition, accommodation, stipend|Location: Austria|Includes short-term and long-term opportunities|Open to Kosovo students.",
    buttonText: "Visit Website", url: "https://studyinaustria.at/en/",
  },
  {
    id: "s-nl", title: "NL Scholarship (Netherlands)", type: "scholarship", typeLabel: "Scholarship",
    country: "europe", countryFlag: "🇳🇱",
    description: "A scholarship for international students who want to study in the Netherlands.|Key details:|Coverage: €5,000 grant|Level: future university studies|Open to non-EU students including Kosovo|Offered by Dutch universities.",
    buttonText: "Visit Website", url: "https://www.studyinnl.org/finances/nl-scholarship",
  },
  {
    id: "s-italy", title: "Italian Government Scholarships", type: "scholarship", typeLabel: "Scholarship",
    country: "europe", countryFlag: "🇮🇹",
    description: "Scholarships offered by Italy for international students to study in Italian institutions.|Key details:|Coverage: tuition + monthly allowance|Level: future studies|Includes many English-taught programs|Open to Kosovo students.",
    buttonText: "Visit Website", url: "https://studyinitaly.esteri.it/",
  },
  {
    id: "s-eiffel", title: "Eiffel Excellence Scholarship", type: "scholarship", typeLabel: "Scholarship",
    country: "france", countryFlag: "🇫🇷",
    description: "A prestigious French government scholarship for top international students.|Key details:|Coverage: monthly stipend + travel|Level: future university studies|Highly competitive|Open internationally.",
    buttonText: "Visit Website", url: "https://www.campusfrance.org/en/eiffel-scholarship-program-of-excellence",
  },
  {
    id: "s-czech", title: "Czech Government Scholarships", type: "scholarship", typeLabel: "Scholarship",
    country: "europe", countryFlag: "🇨🇿",
    description: "Scholarships for international students to study in the Czech Republic.|Key details:|Coverage: tuition + stipend|Level: future university studies|Popular among Balkan students|Fully funded options available.",
    buttonText: "Visit Website", url: "https://www.studyin.cz/scholarships/",
  },
  {
    id: "s-poland", title: "Polish National Agency Scholarships", type: "scholarship", typeLabel: "Scholarship",
    country: "europe", countryFlag: "🇵🇱",
    description: "Scholarships offered by Poland for international students through NAWA programs.|Key details:|Coverage: tuition + stipend|Level: future studies|Open to many countries including Kosovo|Increasingly popular in Europe.",
    buttonText: "Visit Website", url: "https://nawa.gov.pl/en/",
  },
  {
    id: "s-chevening", title: "Chevening Scholarships (UK)", type: "scholarship", typeLabel: "Scholarship",
    country: "uk", countryFlag: "🇬🇧",
    description: "The UK's government global scholarship program for outstanding students.|Key details:|Coverage: tuition, travel, living expenses|Level: postgraduate studies|Focus: leadership and academic excellence|Open to international students including Kosovo.",
    buttonText: "Visit Website", url: "https://www.chevening.org/",
  },
];

// ============ PROGRAMS ============
export const programs: Opportunity[] = [
  {
    id: "p-yes", title: "Youth Exchange and Study Program (YES)", type: "program", typeLabel: "Program",
    country: "usa", countryFlag: "🇺🇸",
    description: "The YES program is a fully funded exchange program supported by the U.S. Department of State that allows students from countries with significant Muslim populations, including Kosovo, to study in an American high school for one year.|Key details:|Age: usually 15–17 years old|Duration: 1 academic year|Coverage: flights, tuition, housing with host family, insurance, and stipend",
    buttonText: "Visit Website", url: "https://exchanges.state.gov/non-us/program/kennedy-lugar-youth-exchange-study-yes",
  },
  {
    id: "p-techgirls", title: "TechGirls", type: "program", typeLabel: "Program",
    country: "usa", countryFlag: "🇺🇸",
    description: "A fully funded STEM exchange program for girls that brings students from many countries to the United States for technology training and leadership development.|Key details:|Age: 15–17|Duration: about 3–4 weeks in the U.S. + mentoring|Focus: coding, engineering, entrepreneurship, leadership|Activities: tech workshops, university visits, cultural exchange",
    buttonText: "Visit Website", url: "https://techgirlsglobal.org",
  },
  {
    id: "p-rsi", title: "Research Science Institute (RSI)", type: "program", typeLabel: "Program",
    country: "usa", countryFlag: "🇺🇸",
    description: "One of the most prestigious STEM programs in the world, hosted at MIT.|Key details:|6-week research program|Students conduct original scientific research with mentors|The program is fully funded.",
    buttonText: "Visit Website", url: "https://www.cee.org/programs/research-science-institute",
  },
  {
    id: "p-mission", title: "Mission Discovery", type: "program", typeLabel: "Program",
    country: "usa", countryFlag: "🇺🇸",
    description: "A program where students collaborate with astronauts and scientists to design space experiments.|Highlights:|STEM workshops|Space mission design|Teamwork and presentations.",
    buttonText: "Visit Website", url: "https://www.isset.space/pages/missiondiscovery",
  },
  {
    id: "p-legacy", title: "Legacy International – On-Demand Youth Leadership Program (ODYLP)", type: "program", typeLabel: "Program",
    country: "usa", countryFlag: "🇺🇸",
    description: "A leadership exchange program run by the U.S. Department of State that brings high school students together to learn about civic engagement, community leadership, and teamwork.|Key details:|Age: about 15–18|Activities: workshops, leadership training, cultural visits, community service|Includes international youth groups and mentors|Often involves short exchanges in different countries.",
    buttonText: "Visit Website", url: "https://legacyintl.org/odylp",
  },
  {
    id: "p-primes", title: "MIT PRIMES (Mathematics Research Program)", type: "program", typeLabel: "Program",
    country: "usa", countryFlag: "🇺🇸",
    description: "A year-long research program where students work with mathematicians and publish research papers.|Fields:|Mathematics|Computer science|Data science",
    buttonText: "Visit Website", url: "https://math.mit.edu/research/highschool/primes/",
  },
  {
    id: "p-eyp", title: "European Youth Parliament", type: "program", typeLabel: "Program",
    country: "international", countryFlag: "🌍",
    description: "A large European youth network where high school students debate global issues and create policy proposals.|Key details:|Age: usually 16–19|Activities: debates, committees, international sessions|Students represent their countries in simulations of European politics.",
    buttonText: "Visit Website", url: "https://eyp.org/",
  },
  {
    id: "p-uwc", title: "United World Colleges (UWC)", type: "program", typeLabel: "Program",
    country: "international", countryFlag: "🌍",
    description: "An international boarding school program where students study the IB diploma in countries across Europe and the world.|Key details:|Age: 16–18|Duration: 2 years|Focus: global education, leadership, cultural exchange|Many students receive full or partial scholarships.",
    buttonText: "Visit Website", url: "https://www.uwc.org/",
  },
  {
    id: "p-erasmus", title: "Erasmus+ Youth Exchanges", type: "program", typeLabel: "Program",
    country: "europe", countryFlag: "🇪🇺",
    description: "Short-term international exchange programs across Europe where students collaborate on projects and cultural activities.|Key details:|Age: 13–18+|Duration: 1–3 weeks|Focus: culture, teamwork, leadership|Often fully funded by the European Union.",
    buttonText: "Visit Website", url: "https://youth.europa.eu/youth-exchanges_en",
  },
  {
    id: "p-mostar", title: "UWC Mostar Summer Programs", type: "program", typeLabel: "Program",
    country: "europe", countryFlag: "🇧🇦",
    description: "Short-term international programs held in Bosnia and Herzegovina focusing on leadership and intercultural dialogue.|Key details:|Age: 15–18|Duration: 1–2 weeks|Focus: peacebuilding, leadership, global issues|Includes students from across Europe.",
    buttonText: "Visit Website", url: "https://www.uwcmostar.ba/",
  },
  {
    id: "p-alpbach", title: "European Forum Alpbach Youth Program", type: "program", typeLabel: "Program",
    country: "europe", countryFlag: "🇦🇹",
    description: "A prestigious Austrian program bringing young people together to discuss science, politics, and global challenges.|Key details:|Age: 16+|Duration: summer program|Focus: leadership, policy, innovation|Includes seminars, discussions, and networking.",
    buttonText: "Visit Website", url: "https://www.alpbach.org/",
  },
  {
    id: "p-issyp", title: "International Summer School for Young Physicists (ISSYP)", type: "program", typeLabel: "Program",
    country: "europe", countryFlag: "🌍",
    description: "An advanced physics summer school hosted in Europe for talented high school students interested in physics.|Key details:|Age: 16–18|Duration: 2 weeks|Focus: physics, research, collaboration|Includes lectures and lab work.",
    buttonText: "Visit Website", url: "https://www.perimeterinstitute.ca/issyp",
  },
  {
    id: "p-cern", title: "CERN High School Students Programme", type: "program", typeLabel: "Program",
    country: "europe", countryFlag: "🇨🇭",
    description: "A science program at CERN in Switzerland where students explore particle physics and research.|Key details:|Age: 16–19|Duration: 1–2 weeks|Focus: physics, engineering, research|Includes lectures, experiments, and visits.",
    buttonText: "Visit Website", url: "https://home.cern/schools-students",
  },
  {
    id: "p-mun", title: "Model United Nations (MUN) Conferences", type: "program", typeLabel: "Program",
    country: "international", countryFlag: "🌍",
    description: "International conferences where students simulate United Nations committees and debate global issues.|Key details:|Age: high school|Duration: 2–5 days|Focus: diplomacy, policy, public speaking|Events are held across Europe.",
    buttonText: "Visit Website", url: "https://bestdelegate.com/",
  },
  {
    id: "p-germany", title: "Germany Exchange Programs", type: "program", typeLabel: "Program",
    country: "germany", countryFlag: "🇩🇪",
    description: "Various exchange programs for students to study and live in Germany.|Key details:|Duration: 1 semester to 1 year|Coverage: partial to full scholarships available|Focus: language learning, cultural exchange|Open to Kosovo students.",
    buttonText: "Visit Website", url: "https://www.daad.de/en/",
  },
  {
    id: "p-france", title: "France Summer Programs", type: "program", typeLabel: "Program",
    country: "france", countryFlag: "🇫🇷",
    description: "Summer programs in France for international students focusing on language and culture.|Key details:|Age: 15–18|Duration: 2–6 weeks|Focus: French language, culture, arts|Various scholarships available.",
    buttonText: "Visit Website", url: "https://www.campusfrance.org/en",
  },
  {
    id: "p-uk", title: "UK Summer Schools", type: "program", typeLabel: "Program",
    country: "uk", countryFlag: "🇬🇧",
    description: "Summer programs at prestigious UK universities including Oxford, Cambridge, and others.|Key details:|Age: 14–18|Duration: 1–4 weeks|Focus: academic subjects, leadership|Various scholarship options available.",
    buttonText: "Visit Website", url: "https://www.britishcouncil.org/",
  },
];

// ============ OTHER ============
export const otherOpportunities: Opportunity[] = [
  {
    id: "o-usa-guide", title: "USA College Scholarships & Guide", type: "other", typeLabel: "Guide",
    country: "usa", countryFlag: "🇺🇸",
    description: "A dedicated section for students who want to study in the United States.|Includes:|Full scholarships|Application guides|SAT/TOEFL info|Tips for Kosovo students",
    buttonText: "Open Section", internalLink: "/usa",
  },
  {
    id: "o-cpc", title: "American Advising Center – College Prep Club (CPC)", type: "other", typeLabel: "Local",
    country: "kosovo", countryFlag: "🇽🇰",
    description: "A highly competitive advising program in Kosovo that helps high school students prepare for studying in the United States.|Key details:|Age: Grade 10-12 students|Activities: SAT prep, essay writing, college advising, workshops|Includes community service and leadership activities|Helps students become strong applicants for U.S. universities.",
    buttonText: "Visit Website", url: "https://aacks.org/home/collegeprepclub/",
  },
  {
    id: "o-toka", title: "TOKA – Camps & Trainings", type: "other", typeLabel: "Local",
    country: "kosovo", countryFlag: "🇽🇰",
    description: "Youth development program offering camps and trainings in leadership, life skills, and community projects.|Activities:|Workshops, teamwork projects, service-learning|Focus: leadership, volunteering, personal growth|Open to students across Kosovo and the region.",
    buttonText: "Visit Website", url: "https://toka-ks.org/program/kampet-dhe-trajnimet/",
  },
  {
    id: "o-mos", title: "Meeting of Styles Kosovo – Volunteering", type: "other", typeLabel: "Local",
    country: "kosovo", countryFlag: "🇽🇰",
    description: "Offers volunteering opportunities at street art events, workshops, and community projects.|Activities:|Event organization, art workshops, community engagement|Focus: arts, culture, teamwork|Great for students building local experience and creative portfolios.",
    buttonText: "Visit Page", url: "https://www.facebook.com/MOSkosovo/",
  },
  {
    id: "o-termokiss", title: "Termokiss – Youth Volunteering & Community Projects", type: "other", typeLabel: "Local",
    country: "kosovo", countryFlag: "🇽🇰",
    description: "Termokiss organizes youth volunteer programs in social work and community service.|Activities:|Volunteering, community outreach, youth initiatives|Focus: civic engagement, teamwork, social impact|Open to motivated high school students.",
    buttonText: "Visit Website", url: "https://www.facebook.com/Termokiss/",
  },
  {
    id: "o-ideas", title: "Ideas Partnership – Internships & Workshops", type: "other", typeLabel: "Local",
    country: "kosovo", countryFlag: "🇽🇰",
    description: "Provides students with internships, workshops, and skill-building sessions in leadership and entrepreneurship.|Activities:|Workshops, internships, mentorship|Focus: innovation, leadership, project management|Helps build professional and academic portfolios.",
    buttonText: "Visit Website", url: "https://theideaspartnership.org/wp/",
  },
  {
    id: "o-esc", title: "European Solidarity Corps", type: "other", typeLabel: "Volunteering",
    country: "europe", countryFlag: "🇪🇺",
    description: "A European Union initiative that offers volunteering projects across Europe.|Key details:|Duration: 2–12 months|Coverage: travel, accommodation, stipend|Open to young people including Kosovo.",
    buttonText: "Visit Website", url: "https://europa.eu/youth/solidarity_en",
  },
  {
    id: "o-forage", title: "Forage Virtual Internships", type: "other", typeLabel: "Internship",
    country: "international", countryFlag: "🌍",
    description: "Free online internship simulations with companies like Google, Deloitte, and Microsoft.|Key details:|Duration: self-paced|Focus: business, tech, law|Great for CV building.",
    buttonText: "Visit Website", url: "https://www.theforage.com/",
  },
  {
    id: "o-4eu", title: "4EU+ Internships", type: "other", typeLabel: "Internship",
    country: "europe", countryFlag: "🇪🇺",
    description: "A platform listing internships and training opportunities across Europe.|Key details:|Includes youth programs and short-term internships|Useful for students planning ahead.",
    buttonText: "Visit Website", url: "https://4euplus.eu/4EU-8.html",
  },
  {
    id: "o-google", title: "Google Science Fair (Global Competitions)", type: "other", typeLabel: "Competition",
    country: "international", countryFlag: "🌍",
    description: "Global science and innovation competitions where students present projects and ideas.|Key details:|Focus: STEM, innovation|Open internationally.",
    buttonText: "Visit Website", url: "https://edu.google.com/",
  },
  {
    id: "o-essay", title: "International Essay Competitions", type: "other", typeLabel: "Competition",
    country: "international", countryFlag: "🌍",
    description: "Various global essay contests open to high school students.|Key details:|Focus: writing, critical thinking|Many are free to enter.",
    buttonText: "Visit Website", url: "https://www.lumiere-education.com/post/free-writing-competitions-for-high-school-students",
  },
  {
    id: "o-coursera", title: "Coursera Free Courses", type: "other", typeLabel: "Learning",
    country: "international", countryFlag: "🌍",
    description: "Online courses from universities like Stanford and Google.|Key details:|Topics: business, tech, science|Certificates available.",
    buttonText: "Visit Website", url: "https://www.coursera.org/",
  },
  {
    id: "o-edx", title: "edX Online Courses", type: "other", typeLabel: "Learning",
    country: "international", countryFlag: "🌍",
    description: "Free courses from top universities including Harvard and MIT.|Key details:|Flexible learning|Wide range of subjects.",
    buttonText: "Visit Website", url: "https://www.edx.org/",
  },
];

// ============ USA GUIDE ============
export const usaGuide: Opportunity[] = [
  {
    id: "u-need", title: "Need-Based Full Scholarships (Top Universities)", type: "scholarship", typeLabel: "Scholarship",
    country: "usa", countryFlag: "🇺🇸",
    description: "Universities like Harvard, Yale, and Princeton offer full financial aid.|Coverage:|Full tuition, housing, food|Based on financial need|Extremely competitive but possible.",
    buttonText: "Learn More", url: "https://college.harvard.edu/financial-aid",
  },
  {
    id: "u-merit", title: "Merit-Based Scholarships (Universities)", type: "scholarship", typeLabel: "Scholarship",
    country: "usa", countryFlag: "🇺🇸",
    description: "Scholarships based on academic results and activities.|Coverage:|Partial to full|Offered by many universities|More accessible than top schools.",
    buttonText: "Learn More", url: "https://www.commonapp.org/",
  },
  {
    id: "u-assist", title: "ASSIST Scholars Program", type: "scholarship", typeLabel: "Scholarship",
    country: "usa", countryFlag: "🇺🇸",
    description: "Places talented international students into top private high schools in the United States.|Key details:|Age: 15–17|Duration: 1 academic year|Coverage: large tuition scholarships",
    buttonText: "Visit Website", url: "https://www.assistscholars.org/",
  },
  {
    id: "u-yfu", title: "YFU Scholarships", type: "scholarship", typeLabel: "Scholarship",
    country: "usa", countryFlag: "🇺🇸",
    description: "Global exchange program offering scholarships for high school students to study in the USA.|Key details:|Partial to full scholarships|Focus on cultural exchange and leadership|Open to Kosovo students through partners.",
    buttonText: "Visit Website", url: "https://yfuusa.org/study/scholarships/",
  },
  {
    id: "u-sat", title: "SAT / ACT Exams", type: "other", typeLabel: "Exam",
    country: "usa", countryFlag: "🇺🇸",
    description: "Standardized tests used by many universities.|Details:|SAT: math + reading|Optional at some schools|Recommended for scholarships.",
    buttonText: "Learn More", url: "https://satsuite.collegeboard.org/",
  },
  {
    id: "u-toefl", title: "TOEFL / IELTS (English Tests)", type: "other", typeLabel: "Exam",
    country: "usa", countryFlag: "🇺🇸",
    description: "Required for international students to prove English proficiency.|Details:|Shows English proficiency|Accepted by almost all universities.",
    buttonText: "Learn More", url: "https://www.ets.org/toefl",
  },
  {
    id: "u-common", title: "Common Application", type: "other", typeLabel: "Application",
    country: "usa", countryFlag: "🇺🇸",
    description: "Main platform for applying to U.S. universities.|Details:|Apply to multiple schools at once|Submit essays, grades, activities.",
    buttonText: "Open Platform", url: "https://www.commonapp.org/",
  },
  {
    id: "u-essay", title: "Personal Essay (Very Important)", type: "other", typeLabel: "Application",
    country: "usa", countryFlag: "🇺🇸",
    description: "One of the most important parts of your application.|Tips:|Focus on your story and impact|Can determine acceptance.",
    buttonText: "Learn More", url: "https://www.commonapp.org/blog",
  },
  {
    id: "u-strategy", title: "Application Strategy for Kosovo Students", type: "other", typeLabel: "Strategy",
    country: "usa", countryFlag: "🇺🇸",
    description: "Strategic advice for international applicants.|Tips:|Apply to 8–12 universities|Mix of top + medium + safe schools|Build strong extracurriculars|Apply early if possible.",
    buttonText: "📄 View Full Guide", url: "https://docs.google.com/document/d/e/2PACX-1vT9CbLKKcd7U9yPyu0pW0rq75y78P8Xgvdg3YPP5GctxzfHmEDVPSeHdf_Jb0FXkHFOCdoVyK6n0liE/pub",
  },
  {
    id: "u-lookfor", title: "What Universities Look For", type: "other", typeLabel: "Advice",
    country: "usa", countryFlag: "🇺🇸",
    description: "Key factors in admissions decisions.|Factors:|Leadership|Initiative and projects|Awards and achievements|Strong grades.",
    buttonText: "📄 View Full Guide", url: "https://docs.google.com/document/d/e/2PACX-1vT9CbLKKcd7U9yPyu0pW0rq75y78P8Xgvdg3YPP5GctxzfHmEDVPSeHdf_Jb0FXkHFOCdoVyK6n0liE/pub",
  },
  {
    id: "u-tips", title: "Tips for Kosovo Students", type: "other", typeLabel: "Advice",
    country: "usa", countryFlag: "🇺🇸",
    description: "Practical advice specifically for Kosovo applicants.|Tips:|Start early|Join programs and competitions|Build a strong profile|Use fee waivers.",
    buttonText: "📄 View Full Guide", url: "https://docs.google.com/document/d/e/2PACX-1vT9CbLKKcd7U9yPyu0pW0rq75y78P8Xgvdg3YPP5GctxzfHmEDVPSeHdf_Jb0FXkHFOCdoVyK6n0liE/pub",
  },
  {
    id: "u-timeline", title: "Application Timeline", type: "other", typeLabel: "Timeline",
    country: "usa", countryFlag: "🇺🇸",
    description: "When to complete each step of your application.|Timeline:|Grade 10–11: build profile|Summer before Grade 12: essays|Nov–Jan: applications|March–April: results.",
    buttonText: "📄 View Full Guide", url: "https://docs.google.com/document/d/e/2PACX-1vT9CbLKKcd7U9yPyu0pW0rq75y78P8Xgvdg3YPP5GctxzfHmEDVPSeHdf_Jb0FXkHFOCdoVyK6n0liE/pub",
  },
  {
    id: "u-docs", title: "Required Documents", type: "other", typeLabel: "Checklist",
    country: "usa", countryFlag: "🇺🇸",
    description: "Everything you need to prepare for your application.|Documents:|Transcript|Recommendation letters|Essay|Test scores|Activities list.",
    buttonText: "📄 View Full Guide", url: "https://docs.google.com/document/d/e/2PACX-1vT9CbLKKcd7U9yPyu0pW0rq75y78P8Xgvdg3YPP5GctxzfHmEDVPSeHdf_Jb0FXkHFOCdoVyK6n0liE/pub",
  },
  {
    id: "u-fees", title: "Application Fees & Waivers", type: "other", typeLabel: "Finances",
    country: "usa", countryFlag: "🇺🇸",
    description: "Understanding and reducing application costs.|Details:|Fees: $50–$90 per university|Fee waivers available|Many Kosovo students qualify.",
    buttonText: "📄 View Full Guide", url: "https://docs.google.com/document/d/e/2PACX-1vT9CbLKKcd7U9yPyu0pW0rq75y78P8Xgvdg3YPP5GctxzfHmEDVPSeHdf_Jb0FXkHFOCdoVyK6n0liE/pub",
  },
  {
    id: "u-types", title: "Types of Universities", type: "other", typeLabel: "Guide",
    country: "usa", countryFlag: "🇺🇸",
    description: "Understanding different types of U.S. universities.|Types:|Ivy League|Liberal Arts Colleges|Public universities|Private universities.",
    buttonText: "📄 View Full Guide", url: "https://docs.google.com/document/d/e/2PACX-1vT9CbLKKcd7U9yPyu0pW0rq75y78P8Xgvdg3YPP5GctxzfHmEDVPSeHdf_Jb0FXkHFOCdoVyK6n0liE/pub",
  },
  {
    id: "u-early", title: "Early vs Regular Decision", type: "other", typeLabel: "Strategy",
    country: "usa", countryFlag: "🇺🇸",
    description: "Understanding application deadlines and their implications.|Options:|Early: higher chances, binding|Regular: more flexibility.",
    buttonText: "📄 View Full Guide", url: "https://docs.google.com/document/d/e/2PACX-1vT9CbLKKcd7U9yPyu0pW0rq75y78P8Xgvdg3YPP5GctxzfHmEDVPSeHdf_Jb0FXkHFOCdoVyK6n0liE/pub",
  },
  {
    id: "u-gpa", title: "GPA & Grades", type: "other", typeLabel: "Academics",
    country: "usa", countryFlag: "🇺🇸",
    description: "Understanding how grades factor into admissions.|Details:|GPA matters|Course difficulty matters|Improvement is important.",
    buttonText: "📄 View Full Guide", url: "https://docs.google.com/document/d/e/2PACX-1vT9CbLKKcd7U9yPyu0pW0rq75y78P8Xgvdg3YPP5GctxzfHmEDVPSeHdf_Jb0FXkHFOCdoVyK6n0liE/pub",
  },
  {
    id: "u-extra", title: "Extracurricular Activities", type: "other", typeLabel: "Activities",
    country: "usa", countryFlag: "🇺🇸",
    description: "Building a strong activities profile.|Ideas:|Clubs|Volunteering|Competitions|Personal projects.",
    buttonText: "📄 View Full Guide", url: "https://docs.google.com/document/d/e/2PACX-1vT9CbLKKcd7U9yPyu0pW0rq75y78P8Xgvdg3YPP5GctxzfHmEDVPSeHdf_Jb0FXkHFOCdoVyK6n0liE/pub",
  },
  {
    id: "u-standout", title: "How to Stand Out", type: "other", typeLabel: "Strategy",
    country: "usa", countryFlag: "🇺🇸",
    description: "Making your application memorable.|Tips:|Leadership|Unique projects|Achievements|Strong story.",
    buttonText: "📄 View Full Guide", url: "https://docs.google.com/document/d/e/2PACX-1vT9CbLKKcd7U9yPyu0pW0rq75y78P8Xgvdg3YPP5GctxzfHmEDVPSeHdf_Jb0FXkHFOCdoVyK6n0liE/pub",
  },
  {
    id: "u-visa", title: "Visa Process (F-1)", type: "other", typeLabel: "Visa",
    country: "usa", countryFlag: "🇺🇸",
    description: "Getting your student visa after acceptance.|Steps:|Get I-20|Pay SEVIS|Embassy interview|Most students get approved.",
    buttonText: "📄 View Full Guide", url: "https://docs.google.com/document/d/e/2PACX-1vT9CbLKKcd7U9yPyu0pW0rq75y78P8Xgvdg3YPP5GctxzfHmEDVPSeHdf_Jb0FXkHFOCdoVyK6n0liE/pub",
  },
  {
    id: "u-reality", title: "Reality Check", type: "other", typeLabel: "Advice",
    country: "usa", countryFlag: "🇺🇸",
    description: "Honest assessment of the application process.|Reality:|Very competitive|Apply widely|Start early|Scholarships are possible.",
    buttonText: "📄 View Full Guide", url: "https://docs.google.com/document/d/e/2PACX-1vT9CbLKKcd7U9yPyu0pW0rq75y78P8Xgvdg3YPP5GctxzfHmEDVPSeHdf_Jb0FXkHFOCdoVyK6n0liE/pub",
  },
];
