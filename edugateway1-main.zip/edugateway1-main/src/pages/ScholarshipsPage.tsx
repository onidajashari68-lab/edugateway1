import { useLanguage } from "@/hooks/useLanguage";
import { scholarships } from "@/data/opportunities";
import OpportunityList from "@/components/OpportunityList";

export default function ScholarshipsPage() {
  const { t } = useLanguage();

  return (
    <section className="px-6 py-20">
      <div className="container">
        <h1 className="mb-5 text-3xl font-extrabold tracking-tight text-foreground">{t("Scholarships")}</h1>
        <OpportunityList cards={scholarships} showTypeFilter={false} />
      </div>
    </section>
  );
}
