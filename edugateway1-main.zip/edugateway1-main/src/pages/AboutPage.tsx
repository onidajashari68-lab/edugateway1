import { useLanguage } from "@/hooks/useLanguage";
import { Mail, Heart, Target, User } from "lucide-react";

export default function AboutPage() {
  const { t } = useLanguage();

  return (
    <section className="px-6 py-20">
      <div className="container max-w-3xl">
        {/* Header with accent */}
        <div className="mb-10 rounded-xl bg-gradient-to-r from-[hsl(var(--primary)/0.08)] to-[hsl(var(--accent-purple)/0.06)] p-8">
          <h1 className="mb-4 text-3xl font-extrabold tracking-tight text-foreground">{t("About EduGateway")}</h1>
          <p className="text-muted-foreground">
            {t("EduGateway is a platform created to help high school students in Kosovo discover scholarships, programs, and other opportunities around the world.")}
          </p>
          <p className="mt-3 text-muted-foreground">
            {t("Many talented students miss life-changing opportunities simply because they don't hear about them. EduGateway brings them all together in one place, making it easier to find the right opportunities.")}
          </p>
        </div>

        {/* Creator section */}
        <div className="mb-8 rounded-xl border border-border bg-card p-7 shadow-sm transition-all duration-300 hover:shadow-card">
          <div className="mb-4 flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-lg bg-gradient-to-br from-[hsl(var(--program-color)/0.15)] to-[hsl(var(--primary)/0.1)]">
              <User className="h-5 w-5 text-[hsl(var(--program-color))]" />
            </div>
            <h2 className="text-xl font-extrabold tracking-tight text-foreground">{t("About the Creator")}</h2>
          </div>
          <p className="mb-4 text-muted-foreground">
            {t("My name is Onida, and I am a high school student from Kosovo. I built this website entirely on my own with the goal of helping my peers access opportunities that I wish had been easier to find when I was searching.")}
          </p>
          <p className="mb-4 text-muted-foreground">
            {t("As a student passionate about education and technology, I wanted to create a space where students could explore scholarships, programs, and extracurricular opportunities without barriers.")}
          </p>
          <p className="text-muted-foreground">
            {t("EduGateway is my way of giving back to the student community in Kosovo, empowering others to take part in programs that can change their academic and personal lives.")}
          </p>
        </div>

        {/* Mission section */}
        <div className="mb-8 rounded-xl border border-border bg-card p-7 shadow-sm transition-all duration-300 hover:shadow-card">
          <div className="mb-4 flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-lg bg-gradient-to-br from-[hsl(var(--other-color)/0.15)] to-[hsl(var(--primary)/0.1)]">
              <Target className="h-5 w-5 text-[hsl(var(--other-color))]" />
            </div>
            <h2 className="text-xl font-extrabold tracking-tight text-foreground">{t("My Mission")}</h2>
          </div>
          <p className="text-muted-foreground">
            {t("To collect, organize, and share educational opportunities for students in Kosovo and beyond, helping them discover pathways to growth, leadership, and global learning.")}
          </p>
        </div>

        {/* Contact */}
        <div className="rounded-xl border border-border bg-gradient-to-r from-[hsl(var(--primary)/0.06)] to-[hsl(var(--accent-purple)/0.04)] p-8 shadow-sm transition-all duration-300 hover:shadow-card">
          <div className="mb-4 flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-lg bg-gradient-to-br from-[hsl(var(--scholarship-color)/0.15)] to-[hsl(var(--primary)/0.1)]">
              <Heart className="h-5 w-5 text-[hsl(var(--scholarship-color))]" />
            </div>
            <h3 className="text-lg font-bold text-foreground">{t("Get in Touch")}</h3>
          </div>
          <p className="mb-5 text-muted-foreground">
            {t("Have questions, suggestions, or want to contribute opportunities? Feel free to reach out!")}
          </p>
          <a
            href="mailto:jasharionida32@gmail.com?subject=EduGateway%20Contact&body=Hello%2C%20I%20would%20like%20to%20get%20in%20touch%20regarding%20EduGateway."
            title={t("Send us an email")}
            aria-label={t("Send us an email")}
            className="gradient-btn inline-flex items-center gap-2 rounded-full px-6 py-3.5 text-[15px] font-semibold text-primary-foreground transition-all hover:-translate-y-0.5"
          >
            <Mail size={16} />
            {t("Contact Us")}
          </a>
        </div>
      </div>
    </section>
  );
}
