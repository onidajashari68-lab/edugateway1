import { useLanguage } from "@/hooks/useLanguage";
import { programs } from "@/data/opportunities";
import OpportunityList from "@/components/OpportunityList";

export default function ProgramsPage() {
  const { t } = useLanguage();

  return (
    <section className="px-6 py-20">
      <div className="container">
        <h1 className="mb-5 text-3xl font-extrabold tracking-tight text-foreground">{t("Programs")}</h1>
        <OpportunityList cards={programs} showTypeFilter={false} />
      </div>
    </section>
  );
}
