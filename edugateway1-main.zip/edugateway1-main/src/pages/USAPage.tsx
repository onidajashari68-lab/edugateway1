import { useLanguage } from "@/hooks/useLanguage";
import { usaGuide } from "@/data/opportunities";
import OpportunityList from "@/components/OpportunityList";

export default function USAPage() {
  const { t } = useLanguage();

  return (
    <section className="px-6 py-20">
      <div className="container">
        <h1 className="mb-5 text-3xl font-extrabold tracking-tight text-foreground">{t("USA Scholarships & Application Guide")}</h1>
        <p className="mb-6 text-muted-foreground">
          {t("This section helps students from Kosovo understand how to study in the United States, including scholarships, exams, and application strategies.")}
        </p>
        <OpportunityList cards={usaGuide} />
      </div>
    </section>
  );
}
