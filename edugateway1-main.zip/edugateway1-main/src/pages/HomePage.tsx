import { Link } from "react-router-dom";
import { useLanguage } from "@/hooks/useLanguage";
import { homeTopPicks } from "@/data/opportunities";
import OpportunityCard from "@/components/OpportunityCard";
import heroBg from "@/assets/hero-bg.jpg";

export default function HomePage() {
  const { t } = useLanguage();

  return (
    <div>
      {/* Hero */}
      <section className="gradient-hero relative flex min-h-[520px] flex-col items-center justify-center px-6 py-24 text-center text-primary-foreground">
        {/* Background image */}
        <img
          src={heroBg}
          alt=""
          width={1920}
          height={1080}
          className="absolute inset-0 h-full w-full object-cover blur-[5px]"
        />
        <div className="relative z-10">
          <h1 className="mx-auto mb-5 max-w-[18ch] text-3xl font-extrabold leading-tight tracking-tight md:text-4xl lg:text-5xl">
            {t("Unlock Global Opportunities for Students Everywhere")}
          </h1>
          <p className="mx-auto mb-4 max-w-xl text-base text-white/90 md:text-lg">
            {t("EduGateway helps high school students from Kosovo and around the world find scholarships, programs, internships, and other educational opportunities.")}
          </p>
          <p className="mx-auto mb-8 max-w-xl text-base text-white/90 md:text-lg">
            {t("Many talented students miss life-changing opportunities simply because they never hear about them. EduGateway brings them together in one place so you can easily explore and apply.")}
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link
              to="/scholarships"
              className="gradient-btn rounded-full px-6 py-3.5 text-[15px] font-semibold text-primary-foreground transition-all hover:-translate-y-0.5"
            >
              {t("Explore Scholarships")}
            </Link>
            <Link
              to="/programs"
              className="rounded-full border-2 border-white bg-transparent px-6 py-3.5 text-[15px] font-semibold text-white transition-all hover:bg-white hover:text-navbar"
            >
              {t("Discover Programs")}
            </Link>
          </div>
        </div>
      </section>

      {/* Start Here */}
      <section className="bg-secondary px-6 py-20">
        <div className="container">
          <div className="mb-7">
            <h2 className="mb-4 text-2xl font-extrabold tracking-tight text-foreground">{t("Start Here")}</h2>
            <p className="max-w-2xl text-muted-foreground">{t("A simple guide to help you find the right opportunity fast.")}</p>
          </div>
          <div className="grid gap-4 md:grid-cols-3">
            {[
              { num: 1, title: "Pick a category", desc: "Start with Scholarships, Programs, or Other and use filters." },
              { num: 2, title: "Check requirements", desc: "Look at age, deadline, and what is covered (tuition, travel, stipend)." },
              { num: 3, title: "Apply early", desc: "Save links, prepare documents, and apply before the deadline." },
            ].map((step) => (
              <div
                key={step.num}
                className="rounded-lg border border-foreground/[0.06] bg-card p-5 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:border-primary/25 hover:shadow-card-hover"
              >
                <div className="gradient-btn mb-2.5 grid h-[34px] w-[34px] place-items-center rounded-[10px] text-sm font-bold text-primary-foreground">
                  {step.num}
                </div>
                <h3 className="mb-1.5 text-base font-bold text-foreground">{t(step.title)}</h3>
                <p className="text-sm text-muted-foreground">{t(step.desc)}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Top Picks */}
      <section className="px-6 py-20">
        <div className="container">
          <div className="mb-7">
            <h2 className="mb-4 text-2xl font-extrabold tracking-tight text-foreground">{t("Top Picks")}</h2>
            <p className="max-w-2xl text-muted-foreground">{t("Popular options many Kosovo students are interested in.")}</p>
          </div>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {homeTopPicks.map((opp) => (
              <OpportunityCard key={opp.id} opportunity={opp} />
            ))}
          </div>
        </div>
      </section>

      {/* Explore by Category */}
      <section className="bg-white px-6 py-20">
        <div className="container">
          <div className="mb-7">
            <h2 className="mb-4 text-2xl font-extrabold tracking-tight text-foreground">{t("Explore by category")}</h2>
            <p className="max-w-2xl text-muted-foreground">{t("Everything is organized so you can find opportunities quickly.")}</p>
          </div>
          <div className="grid gap-12 md:grid-cols-2">
            <div className="space-y-5">
              <FeatureCard
                title={t("Scholarships")}
                desc={t("Find fully funded opportunities from around the globe that can support your education.")}
                link="/scholarships"
                btnText={t("Explore Scholarships")}
              />
              <FeatureCard
                title={t("Programs")}
                desc={t("Explore summer programs, leadership initiatives, and research experiences.")}
                link="/programs"
                btnText={t("Discover Programs")}
              />
            </div>
            <div className="space-y-5">
              <FeatureCard
                title={t("Other Opportunities")}
                desc={t("Competitions, fellowships, volunteering, internships, and online courses.")}
                link="/other"
                btnText={t("See All Opportunities")}
              />
              <div className="rounded-lg border border-foreground/[0.06] bg-card p-7 shadow-sm transition-all duration-300 hover:-translate-y-0.5 hover:shadow-card">
                <h3 className="mb-2.5 text-lg font-bold text-primary">{t("Our Mission")}</h3>
                <p className="text-[15px] text-muted-foreground">
                  {t("To empower students from Kosovo and beyond to find scholarships, programs, and experiences that help them succeed academically, personally, and professionally.")}
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="gradient-cta px-6 py-20 text-center">
        <h2 className="mb-4 text-2xl font-extrabold text-primary-foreground">{t("Start Exploring Opportunities Today")}</h2>
        <p className="mx-auto max-w-2xl text-white/90">
          {t("Whether you are looking for a scholarship, a summer program, or a volunteering opportunity in Kosovo or abroad, EduGateway has curated them for you in one place.")}
        </p>
      </section>
    </div>
  );
}

function FeatureCard({ title, desc, link, btnText }: { title: string; desc: string; link: string; btnText: string }) {
  return (
    <div className="rounded-lg border border-foreground/[0.06] bg-card p-7 shadow-sm transition-all duration-300 hover:-translate-y-0.5 hover:shadow-card">
      <h3 className="mb-2.5 text-lg font-bold text-primary">{title}</h3>
      <p className="text-[15px] text-muted-foreground">{desc}</p>
      <div className="mt-5">
        <Link
          to={link}
          className="gradient-btn inline-flex rounded-full px-6 py-3.5 text-[15px] font-semibold text-primary-foreground transition-all hover:-translate-y-0.5"
        >
          {btnText}
        </Link>
      </div>
    </div>
  );
}
