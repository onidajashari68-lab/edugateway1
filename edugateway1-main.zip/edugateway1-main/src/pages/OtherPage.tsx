import { useLanguage } from "@/hooks/useLanguage";
import { otherOpportunities } from "@/data/opportunities";
import OpportunityList from "@/components/OpportunityList";

export default function OtherPage() {
  const { t } = useLanguage();

  return (
    <section className="px-6 py-20">
      <div className="container">
        <h1 className="mb-5 text-3xl font-extrabold tracking-tight text-foreground">{t("Other Opportunities")}</h1>
        <p className="mb-6 text-muted-foreground">{t("Competitions, fellowships, volunteering, internships, and online courses.")}</p>
        <OpportunityList cards={otherOpportunities} showTypeFilter={false} />
      </div>
    </section>
  );
}
