import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { LanguageProvider } from "@/hooks/useLanguage";
import Navbar from "@/components/Navbar";
import FeedbackButton from "@/components/FeedbackButton";
import HomePage from "@/pages/HomePage";
import ScholarshipsPage from "@/pages/ScholarshipsPage";
import ProgramsPage from "@/pages/ProgramsPage";
import OtherPage from "@/pages/OtherPage";
import AboutPage from "@/pages/AboutPage";
import USAPage from "@/pages/USAPage";
import NotFound from "@/pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <LanguageProvider>
          <Navbar />
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/scholarships" element={<ScholarshipsPage />} />
            <Route path="/programs" element={<ProgramsPage />} />
            <Route path="/other" element={<OtherPage />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/usa" element={<USAPage />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
          <FeedbackButton />
        </LanguageProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
