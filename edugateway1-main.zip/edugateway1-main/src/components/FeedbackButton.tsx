import { useState } from "react";
import { MessageCircle, X } from "lucide-react";
import { useLanguage } from "@/hooks/useLanguage";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

const FORM_URL =
  "https://docs.google.com/forms/d/e/1FAIpQLScou_4D4MGMXUR53EoVw3iZMix-lcHzdTrLJAVq6SUwfo3MKA/viewform?embedded=true";

export default function FeedbackButton() {
  const [open, setOpen] = useState(false);
  const { t } = useLanguage();
  const label = t("Feedback");

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        aria-label={label}
        className="group fixed bottom-5 right-5 z-40 flex items-center gap-2 rounded-full bg-gradient-to-r from-primary to-[hsl(265_85%_60%)] px-4 py-3 text-sm font-semibold text-primary-foreground shadow-lg shadow-primary/30 transition-all hover:scale-105 hover:shadow-xl hover:shadow-primary/50 sm:px-5 sm:py-3.5"
      >
        <MessageCircle className="h-5 w-5" />
        <span className="hidden sm:inline">{label}</span>
      </button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-h-[95vh] w-[95vw] max-w-2xl gap-0 overflow-hidden p-0 sm:max-h-[90vh]">
          <DialogHeader className="border-b bg-gradient-to-r from-primary/10 to-[hsl(265_85%_60%/0.1)] px-5 py-4">
            <DialogTitle className="text-base font-semibold">{label}</DialogTitle>
          </DialogHeader>
          <div className="h-[70vh] w-full overflow-y-auto sm:h-[600px]">
            <iframe
              src={FORM_URL}
              className="h-full min-h-[600px] w-full border-0"
              title={label}
            >
              Loading…
            </iframe>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
