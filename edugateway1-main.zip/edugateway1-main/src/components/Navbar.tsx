import { Link, useLocation } from "react-router-dom";
import { useLanguage } from "@/hooks/useLanguage";
import { useState } from "react";
import { GraduationCap, Menu, X } from "lucide-react";

const navItems = [
  { path: "/", label: "Home" },
  { path: "/scholarships", label: "Scholarships" },
  { path: "/programs", label: "Programs" },
  { path: "/other", label: "Other" },
  { path: "/about", label: "About" },
];

export default function Navbar() {
  const { language, setLanguage, t } = useLanguage();
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <nav className="sticky top-0 z-50 border-b border-foreground/5 bg-navbar text-navbar-foreground shadow-md">
      <div className="container flex h-16 items-center justify-between px-4 lg:px-6">
        {/* Logo */}
        <Link
          to="/"
          className="flex items-center gap-2.5 font-bold text-navbar-foreground no-underline transition-opacity hover:opacity-90"
        >
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary shadow-sm">
            <GraduationCap className="h-5 w-5 text-primary-foreground" />
          </div>
          <span className="text-lg tracking-tight">{t("EduGateway")}</span>
        </Link>

        {/* Desktop nav links */}
        <div className="hidden items-center gap-0.5 lg:flex">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`rounded-lg px-3.5 py-2 text-[13px] font-medium transition-colors ${
                  isActive
                    ? "bg-primary/90 text-primary-foreground shadow-sm"
                    : "text-navbar-foreground/75 hover:bg-navbar-foreground/10 hover:text-navbar-foreground"
                }`}
              >
                {t(item.label)}
              </Link>
            );
          })}
        </div>

        {/* Right side */}
        <div className="flex items-center gap-2">
          <select
            value={language}
            onChange={(e) => setLanguage(e.target.value as "en" | "sq")}
            className="cursor-pointer appearance-none rounded-lg border border-navbar-foreground/20 bg-navbar-foreground/10 px-3 py-1.5 text-[13px] text-navbar-foreground transition-colors hover:border-navbar-foreground/40 hover:bg-navbar-foreground/15 focus:border-primary focus:outline-none"
          >
            <option value="sq" className="bg-navbar text-navbar-foreground">
              {t("Shqip")}
            </option>
            <option value="en" className="bg-navbar text-navbar-foreground">
              {t("English")}
            </option>
          </select>

          <button
            className="rounded-lg p-2 text-navbar-foreground transition-colors hover:bg-navbar-foreground/10 lg:hidden"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label="Toggle menu"
          >
            {mobileOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="animate-fade-in border-t border-navbar-foreground/10 px-4 pb-4 pt-2 lg:hidden">
          <div className="flex flex-col gap-1">
            {navItems.map((item) => {
              const isActive = location.pathname === item.path;
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={() => setMobileOpen(false)}
                  className={`rounded-lg px-4 py-2.5 text-sm font-medium transition-colors ${
                    isActive
                      ? "bg-primary/90 text-primary-foreground"
                      : "text-navbar-foreground/75 hover:bg-navbar-foreground/10 hover:text-navbar-foreground"
                  }`}
                >
                  {t(item.label)}
                </Link>
              );
            })}
          </div>
        </div>
      )}
    </nav>
  );
}
