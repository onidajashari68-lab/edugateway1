import { useLanguage } from "@/hooks/useLanguage";
import { Search, X, Filter } from "lucide-react";

const COUNTRY_LABELS: Record<string, { label: string; flag: string }> = {
  usa: { label: "USA", flag: "🇺🇸" },
  kosovo: { label: "Kosovo", flag: "🇽🇰" },
  germany: { label: "Germany", flag: "🇩🇪" },
  france: { label: "France", flag: "🇫🇷" },
  uk: { label: "UK", flag: "🇬🇧" },
  europe: { label: "Europe", flag: "🇪🇺" },
  international: { label: "International", flag: "🌍" },
};

interface SearchFilterBarProps {
  searchTerm: string;
  onSearchChange: (value: string) => void;
  typeFilter: string;
  onTypeChange: (value: string) => void;
  countryFilter: string;
  onCountryChange: (value: string) => void;
  countries: string[];
  onClearAll: () => void;
  totalCount: number;
  visibleCount: number;
  showTypeFilter?: boolean;
}

export default function SearchFilterBar({
  searchTerm,
  onSearchChange,
  typeFilter,
  onTypeChange,
  countryFilter,
  onCountryChange,
  countries,
  onClearAll,
  totalCount,
  visibleCount,
  showTypeFilter = true,
}: SearchFilterBarProps) {
  const { t } = useLanguage();

  const hasActiveFilters = searchTerm.trim() !== "" || typeFilter !== "all" || countryFilter !== "all";

  return (
    <div className="space-y-3">
      {/* Search input */}
      <div className="relative">
        <Search className="absolute left-4 top-1/2 h-[18px] w-[18px] -translate-y-1/2 text-muted-foreground" />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder={t("Search opportunities")}
          className="w-full rounded-xl border border-border bg-card py-3 pl-11 pr-10 text-sm text-foreground shadow-sm transition-all placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20"
        />
        {searchTerm && (
          <button
            onClick={() => onSearchChange("")}
            className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full p-1 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
          >
            <X size={14} />
          </button>
        )}
      </div>

      {/* Filter dropdowns row */}
      <div className="flex flex-wrap items-center gap-2">
        <Filter className="h-4 w-4 text-muted-foreground" />

        {showTypeFilter && (
          <select
            value={typeFilter}
            onChange={(e) => onTypeChange(e.target.value)}
            className="cursor-pointer rounded-lg border border-border bg-card px-3 py-2 text-sm text-foreground shadow-sm transition-all hover:border-primary/40 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20"
          >
            <option value="all">{t("All Types")}</option>
            <option value="scholarship">{t("Scholarships")}</option>
            <option value="program">{t("Programs")}</option>
            <option value="other">{t("Other")}</option>
          </select>
        )}

        <select
          value={countryFilter}
          onChange={(e) => onCountryChange(e.target.value)}
          className="cursor-pointer rounded-lg border border-border bg-card px-3 py-2 text-sm text-foreground shadow-sm transition-all hover:border-primary/40 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20"
        >
          <option value="all">{t("All Countries")}</option>
          {countries.map((c) => {
            const info = COUNTRY_LABELS[c];
            return (
              <option key={c} value={c}>
                {info ? `${info.flag} ${t(info.label)}` : c}
              </option>
            );
          })}
        </select>

        {hasActiveFilters && (
          <button
            onClick={onClearAll}
            className="ml-auto rounded-lg border border-border px-3 py-2 text-xs font-medium text-muted-foreground transition-colors hover:border-destructive/40 hover:bg-destructive/10 hover:text-destructive"
          >
            {t("Clear all filters")}
          </button>
        )}
      </div>

      {/* Results count */}
      {totalCount > 0 && (
        <div className="flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
          <span>
            {t("Showing")} <strong className="text-foreground">{visibleCount}</strong> {t("of")}{" "}
            <strong className="text-foreground">{totalCount}</strong> {t("opportunities")}
          </span>

          {/* Active filter chips */}
          {searchTerm && (
            <span className="inline-flex items-center gap-1 rounded-full bg-primary/10 px-2.5 py-0.5 text-xs font-medium text-primary">
              "{searchTerm}"
              <button onClick={() => onSearchChange("")} className="rounded-full p-0.5 hover:bg-primary/20">
                <X size={10} />
              </button>
            </span>
          )}
          {typeFilter !== "all" && (
            <span className="inline-flex items-center gap-1 rounded-full bg-primary/10 px-2.5 py-0.5 text-xs font-medium text-primary">
              {t(typeFilter === "scholarship" ? "Scholarships" : typeFilter === "program" ? "Programs" : "Other")}
              <button onClick={() => onTypeChange("all")} className="rounded-full p-0.5 hover:bg-primary/20">
                <X size={10} />
              </button>
            </span>
          )}
          {countryFilter !== "all" && (
            <span className="inline-flex items-center gap-1 rounded-full bg-primary/10 px-2.5 py-0.5 text-xs font-medium text-primary">
              {COUNTRY_LABELS[countryFilter]?.flag} {t(COUNTRY_LABELS[countryFilter]?.label ?? countryFilter)}
              <button onClick={() => onCountryChange("all")} className="rounded-full p-0.5 hover:bg-primary/20">
                <X size={10} />
              </button>
            </span>
          )}
        </div>
      )}
    </div>
  );
}
