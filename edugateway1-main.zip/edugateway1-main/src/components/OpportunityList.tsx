import { Opportunity } from "@/data/opportunities";
import OpportunityCard from "./OpportunityCard";
import SearchFilterBar from "./SearchFilterBar";
import NoResults from "./NoResults";
import { useFilteredCards } from "@/hooks/useFilteredCards";

interface OpportunityListProps {
  cards: Opportunity[];
  showTypeFilter?: boolean;
}

export default function OpportunityList({ cards, showTypeFilter = true }: OpportunityListProps) {
  const {
    filtered, searchTerm, setSearchTerm,
    typeFilter, setTypeFilter,
    countryFilter, setCountryFilter, countries,
    clearAll, total,
  } = useFilteredCards(cards);

  return (
    <div>
      <SearchFilterBar
        searchTerm={searchTerm}
        onSearchChange={setSearchTerm}
        typeFilter={typeFilter}
        onTypeChange={setTypeFilter}
        countryFilter={countryFilter}
        onCountryChange={setCountryFilter}
        countries={countries}
        onClearAll={clearAll}
        totalCount={total}
        visibleCount={filtered.length}
        showTypeFilter={showTypeFilter}
      />

      {filtered.length === 0 && total > 0 ? (
        <NoResults
          onClearAll={clearAll}
          onClearSearch={() => setSearchTerm("")}
          onClearType={() => setTypeFilter("all")}
        />
      ) : (
        <div className="mt-6 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((opp) => (
            <OpportunityCard key={opp.id} opportunity={opp} />
          ))}
        </div>
      )}
    </div>
  );
}
