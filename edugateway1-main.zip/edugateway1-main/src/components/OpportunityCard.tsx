import { Opportunity } from "@/data/opportunities";
import { useLanguage } from "@/hooks/useLanguage";
import { useNavigate } from "react-router-dom";
import { ExternalLink, ArrowRight } from "lucide-react";
import usaFlagImg from "@/assets/usa-flag.png";

function renderDescription(description: string, t: (key: string) => string) {
  const parts = description.split("|");
  const elements: JSX.Element[] = [];

  elements.push(<span key="main">{t(parts[0].trim())}</span>);

  for (let i = 1; i < parts.length; i++) {
    const raw = parts[i].trim();
    const translated = t(raw);
    if (raw.endsWith(":")) {
      elements.push(
        <span key={i}>
          <br /><br /><strong className="text-foreground/80">{translated}</strong>
        </span>
      );
    } else {
      elements.push(
        <span key={i}>
          <br />• {translated}
        </span>
      );
    }
  }

  return elements;
}

interface OpportunityCardProps {
  opportunity: Opportunity;
}

export default function OpportunityCard({ opportunity }: OpportunityCardProps) {
  const { t } = useLanguage();
  const navigate = useNavigate();

  const accentMap = {
    scholarship: {
      badge: "bg-[hsl(var(--scholarship-color)/0.12)] text-[hsl(var(--scholarship-color))] border-[hsl(var(--scholarship-color)/0.2)]",
      gradient: "from-[hsl(var(--scholarship-color)/0.04)] to-transparent",
      border: "hover:border-[hsl(var(--scholarship-color)/0.3)]",
      btn: "bg-gradient-to-r from-[hsl(var(--scholarship-color))] to-[hsl(var(--primary-dark))]",
    },
    program: {
      badge: "bg-[hsl(var(--program-color)/0.12)] text-[hsl(var(--program-color))] border-[hsl(var(--program-color)/0.2)]",
      gradient: "from-[hsl(var(--program-color)/0.04)] to-transparent",
      border: "hover:border-[hsl(var(--program-color)/0.3)]",
      btn: "bg-gradient-to-r from-[hsl(var(--program-color))] to-[hsl(var(--primary))]",
    },
    other: {
      badge: "bg-[hsl(var(--other-color)/0.12)] text-[hsl(var(--other-color))] border-[hsl(var(--other-color)/0.2)]",
      gradient: "from-[hsl(var(--other-color)/0.04)] to-transparent",
      border: "hover:border-[hsl(var(--other-color)/0.3)]",
      btn: "bg-gradient-to-r from-[hsl(var(--other-color))] to-[hsl(var(--primary))]",
    },
  };

  const accent = accentMap[opportunity.type] ?? accentMap.other;
  const isUsaCard = opportunity.id === "home-usa-guide" || opportunity.id === "o-usa-guide";

  const handleInternalClick = () => {
    if (opportunity.internalLink) {
      navigate(opportunity.internalLink);
    }
  };

  const isExternal = !!opportunity.url;

  return (
    <div className={`animate-fade-in group relative flex flex-col overflow-hidden rounded-xl border border-border bg-gradient-to-b ${isUsaCard ? "from-[hsl(220_60%_20%/0.15)] to-[hsl(220_80%_30%/0.05)]" : accent.gradient} bg-card shadow-sm transition-all duration-300 hover:-translate-y-1.5 hover:scale-[1.02] hover:shadow-card-hover ${isUsaCard ? "hover:border-[hsl(var(--scholarship-color)/0.4)] border-[hsl(var(--scholarship-color)/0.15)]" : accent.border}`}>
      <div className="flex flex-1 flex-col p-5">
        {/* Header row */}
        <div className="mb-2 flex items-start justify-between gap-2">
          <h3 className="text-base font-bold leading-snug text-foreground">
            {t(opportunity.title)}
          </h3>
          <span className="flex-shrink-0 text-xl" title={opportunity.country}>
            {opportunity.countryFlag}
          </span>
        </div>

        {/* Type badge */}
        <span className={`mb-3 inline-flex w-fit items-center rounded-md border px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wide ${accent.badge}`}>
          {t(opportunity.typeLabel)}
        </span>

        {/* Description */}
        <p className="flex-1 text-[13px] leading-relaxed text-muted-foreground">
          {renderDescription(opportunity.description, t)}
        </p>

        {/* USA Flag visual */}
        {isUsaCard && (
          <div className="mt-4 flex justify-center">
            <img
              src={usaFlagImg}
              alt="American flag"
              loading="lazy"
              width={512}
              height={512}
              className="h-20 w-20 rounded-lg object-contain opacity-80 shadow-md transition-all duration-300 group-hover:opacity-100 group-hover:shadow-lg sm:h-24 sm:w-24"
            />
          </div>
        )}

        {/* Button — anchor for external URLs avoids iframe popup blocking */}
        {isExternal ? (
          <a
            href={opportunity.url}
            target="_blank"
            rel="noopener noreferrer"
            className={`mt-4 flex w-full cursor-pointer items-center justify-center gap-2 rounded-lg ${accent.btn} px-4 py-2.5 text-sm font-semibold text-primary-foreground shadow-sm transition-all duration-200 hover:shadow-md hover:brightness-110 active:scale-[0.98]`}
          >
            {t(opportunity.buttonText)}
            <ExternalLink size={14} />
          </a>
        ) : (
          <button
            onClick={handleInternalClick}
            className={`mt-4 flex w-full cursor-pointer items-center justify-center gap-2 rounded-lg ${accent.btn} px-4 py-2.5 text-sm font-semibold text-primary-foreground shadow-sm transition-all duration-200 hover:shadow-md hover:brightness-110 active:scale-[0.98]`}
          >
            {t(opportunity.buttonText)}
            <ArrowRight size={14} />
          </button>
        )}
      </div>
    </div>
  );
}
