import { useLanguage } from "@/hooks/useLanguage";
import { SearchX } from "lucide-react";

interface NoResultsProps {
  onClearAll: () => void;
  onClearSearch: () => void;
  onClearType: () => void;
}

export default function NoResults({ onClearAll, onClearSearch, onClearType }: NoResultsProps) {
  const { t } = useLanguage();

  return (
    <div className="animate-fade-in mt-8 rounded-xl bg-card p-10 text-center shadow-sm">
      <SearchX className="mx-auto mb-4 h-12 w-12 text-muted-foreground/40" />
      <h3 className="mb-2 text-lg font-bold text-foreground">{t("No results found")}</h3>
      <p className="mb-5 text-sm text-muted-foreground">{t("Try adjusting your filters or search terms")}</p>
      <div className="flex flex-wrap justify-center gap-2">
        <button
          onClick={onClearAll}
          className="rounded-lg border border-border bg-card px-4 py-2 text-sm font-medium text-foreground transition-colors hover:border-primary hover:bg-primary hover:text-primary-foreground"
        >
          {t("Clear all filters")}
        </button>
        <button
          onClick={onClearSearch}
          className="rounded-lg border border-border bg-card px-4 py-2 text-sm font-medium text-foreground transition-colors hover:border-primary hover:bg-primary hover:text-primary-foreground"
        >
          {t("Try a broader search")}
        </button>
        <button
          onClick={onClearType}
          className="rounded-lg border border-border bg-card px-4 py-2 text-sm font-medium text-foreground transition-colors hover:border-primary hover:bg-primary hover:text-primary-foreground"
        >
          {t("Remove filters")}
        </button>
      </div>
    </div>
  );
}
