import { useState, useMemo } from "react";
import { Opportunity } from "@/data/opportunities";

export function useFilteredCards(cards: Opportunity[]) {
  const [searchTerm, setSearchTerm] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");
  const [countryFilter, setCountryFilter] = useState("all");

  // Extract unique countries from the cards
  const countries = useMemo(() => {
    const set = new Set(cards.map((c) => c.country));
    return Array.from(set).sort();
  }, [cards]);

  const filtered = useMemo(() => {
    return cards.filter((card) => {
      // Type filter
      if (typeFilter !== "all" && card.type !== typeFilter) return false;

      // Country filter
      if (countryFilter !== "all" && card.country !== countryFilter) return false;

      // Search filter - match against visible text
      if (searchTerm.trim()) {
        const query = searchTerm.toLowerCase().trim();
        const haystack = [
          card.title,
          card.typeLabel,
          card.description.replace(/\|/g, " "),
          card.country,
          card.countryFlag,
        ]
          .join(" ")
          .toLowerCase();

        const tokens = query.split(/\s+/).filter(Boolean);
        return tokens.every((token) => haystack.includes(token));
      }

      return true;
    });
  }, [cards, searchTerm, typeFilter, countryFilter]);

  const clearAll = () => {
    setSearchTerm("");
    setTypeFilter("all");
    setCountryFilter("all");
  };

  return {
    filtered,
    searchTerm,
    setSearchTerm,
    typeFilter,
    setTypeFilter,
    countryFilter,
    setCountryFilter,
    countries,
    clearAll,
    total: cards.length,
  };
}
